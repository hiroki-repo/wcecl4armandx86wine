// dllmain.cpp : Defines the entry point for the DLL application.
#include "stdafx.h"
#include <stdio.h>

#undef __stdcall // DllMain should be __stdcall always
BOOL __stdcall DllMain(HMODULE hModule,
	DWORD  ul_reason_for_call,
	LPVOID lpReserved
)
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
	{
		if (MessageBoxExW(
			NULL,
			L"Attach a debugger now?",
			L"Windows CE Compatibility Layer",
			MB_YESNO,
			MAKELANGID(LANG_ENGLISH, SUBLANG_ENGLISH_US)) == IDYES)
		{
			WCHAR VSJitDebugger[MAX_PATH], CmdLineBuf[256], SystemDirectory[MAX_PATH];
			PROCESS_INFORMATION Info = { };
			STARTUPINFO StartupInfo = { };

			GetSystemDirectoryW(SystemDirectory, MAX_PATH);
			swprintf_s(VSJitDebugger, MAX_PATH, L"%s\\vsjitdebugger.exe", SystemDirectory);
			swprintf_s(CmdLineBuf, 256, L"%s -p %d", VSJitDebugger, GetCurrentProcessId());

			StartupInfo.wShowWindow = TRUE;
			
			// MessageBoxW(NULL, CmdLineBuf, VSJitDebugger, 0);

			Assert32(CreateProcess(
				VSJitDebugger,
				CmdLineBuf,
				NULL, NULL,
				FALSE, NORMAL_PRIORITY_CLASS,
				NULL, NULL, &StartupInfo, &Info) == FALSE);

			WaitForSingleObject(Info.hProcess, -1);

			CloseHandle(Info.hProcess);
			CloseHandle(Info.hThread);
		}
		break;
	};
	//
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}

extern "C" int APIENTRY _vsnwprintf_WCECL(
	_Out_writes_opt_(_BufferCount) _Post_maybez_ wchar_t* _Buffer,
	_In_                                         size_t         _BufferCount,
	_In_z_ _Printf_format_string_                wchar_t const* _Format,
	va_list        _ArgList
)
{
	return _vsnwprintf_l(_Buffer, _BufferCount, _Format, NULL, _ArgList);
}

extern "C" int APIENTRY vswprintf_WCECL(
	_Out_writes_opt_(_BufferCount) _Always_(_Post_z_) wchar_t* const _Buffer,
	_In_                                              size_t         const _BufferCount,
	_In_z_ _Printf_format_string_params_(1)           wchar_t const* const _Format,
	va_list              _ArgList
)
{
	return _vswprintf_c_l(_Buffer, _BufferCount, _Format, NULL, _ArgList);
}
