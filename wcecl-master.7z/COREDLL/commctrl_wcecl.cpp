// commctrl_wcecl.cpp : wce/commctrl.h functions
#include "stdafx.h"

// Functions

// Stubs
Stub(ImageList_CopyDitherImage); // ret: void; args: HIMAGELIST himlDest, WORD iDst, int xDst, int yDst, HIMAGELIST himlSrc, int iSrc, UINT fStyle)
