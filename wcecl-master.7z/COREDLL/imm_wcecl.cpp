// wce/imm.h
#include "stdafx.h"

// Functions

// Stubs
Stub(ImmSIPanelState); // ret: BOOL; args: UINT dwCmd, LPVOID pValue
Stub(ImmSetHotKey_WCECL);
